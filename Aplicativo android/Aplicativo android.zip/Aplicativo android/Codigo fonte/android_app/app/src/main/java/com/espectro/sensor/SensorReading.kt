package com.espectro.sensor

data class SensorReading(
    val ir: Int,
    val full: Int,
    val visible: Int,
    val lux: Double
) {
    companion object {
        private val regexLegacy = Regex(
            """IR:\s*(\d+)\s+Full:\s*(\d+)\s+Visible:\s*(\d+)\s+Lux:\s*([\d.]+)""",
            RegexOption.IGNORE_CASE
        )

        private val regexData = Regex(
            """DATA;IR=(\d+);FULL=(\d+);VISIBLE=(\d+);LUX=([\d.]+)""",
            RegexOption.IGNORE_CASE
        )

        fun parse(line: String): SensorReading? {
            val t = line.trim()
            regexData.find(t)?.let { m ->
                return SensorReading(
                    m.groupValues[1].toInt(),
                    m.groupValues[2].toInt(),
                    m.groupValues[3].toInt(),
                    m.groupValues[4].toDouble()
                )
            }
            regexLegacy.find(t)?.let { m ->
                return SensorReading(
                    m.groupValues[1].toInt(),
                    m.groupValues[2].toInt(),
                    m.groupValues[3].toInt(),
                    m.groupValues[4].toDouble()
                )
            }
            return null
        }
    }
}
