package com.espectro.sensor.data

import android.content.Context
import com.espectro.sensor.model.CalibrationCurve
import com.espectro.sensor.model.SampleMeasurement
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class CalibrationRepository(context: Context) {

    private val appContext = context.applicationContext
    private val calibFile = File(appContext.filesDir, "calibrations.json")
    private val measuresFile = File(appContext.filesDir, "measurements.json")

    fun listCalibrations(): List<CalibrationCurve> {
        if (!calibFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(calibFile.readText())
            (0 until arr.length()).map { i ->
                CalibrationCurve.fromJson(arr.getJSONObject(i))
            }.sortedByDescending { it.createdAtMs }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun getCalibration(id: String): CalibrationCurve? =
        listCalibrations().find { it.id == id }

    fun saveCalibration(curve: CalibrationCurve) {
        val all = listCalibrations().filter { it.id != curve.id }.toMutableList()
        all.add(0, curve)
        persistCalibrations(all)
    }

    fun deleteCalibration(id: String) {
        persistCalibrations(listCalibrations().filter { it.id != id })
    }

    private fun persistCalibrations(list: List<CalibrationCurve>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        calibFile.writeText(arr.toString())
    }

    fun listMeasurements(calibrationId: String? = null): List<SampleMeasurement> {
        if (!measuresFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(measuresFile.readText())
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.getJSONObject(i)
                val m = SampleMeasurement(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    calibrationId = o.getString("calibrationId"),
                    calibrationName = o.getString("calibrationName"),
                    full = o.getInt("full"),
                    ir = o.getInt("ir"),
                    visible = o.getInt("visible"),
                    lux = o.getDouble("lux"),
                    concentration = o.getDouble("concentration"),
                    timestampMs = o.getLong("timestampMs")
                )
                if (calibrationId == null || m.calibrationId == calibrationId) m else null
            }.sortedByDescending { it.timestampMs }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveMeasurement(m: SampleMeasurement) {
        val all = listMeasurements().toMutableList()
        all.add(0, m)
        persistMeasurements(all)
    }

    private fun persistMeasurements(list: List<SampleMeasurement>) {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(
                JSONObject()
                    .put("id", m.id)
                    .put("name", m.name)
                    .put("calibrationId", m.calibrationId)
                    .put("calibrationName", m.calibrationName)
                    .put("full", m.full)
                    .put("ir", m.ir)
                    .put("visible", m.visible)
                    .put("lux", m.lux)
                    .put("concentration", m.concentration)
                    .put("timestampMs", m.timestampMs)
            )
        }
        measuresFile.writeText(arr.toString())
    }
}
