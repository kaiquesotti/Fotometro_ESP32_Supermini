package com.espectro.sensor.data

import kotlin.math.pow

data class LinearFit(
    val slope: Double,
    val intercept: Double,
    val rSquared: Double
) {
    fun equationText(): String =
        "y = ${"%.6g".format(slope)}·x + ${"%.6g".format(intercept)}"
}

object LinearRegression {
    fun fit(points: List<Pair<Double, Double>>): LinearFit? {
        if (points.size < 2) return null

        val n = points.size
        val sumX = points.sumOf { it.first }
        val sumY = points.sumOf { it.second }
        val sumXY = points.sumOf { it.first * it.second }
        val sumX2 = points.sumOf { it.first.pow(2) }
        val sumY2 = points.sumOf { it.second.pow(2) }

        val denom = n * sumX2 - sumX * sumX
        if (denom == 0.0) return null

        val slope = (n * sumXY - sumX * sumY) / denom
        val intercept = (sumY - slope * sumX) / n

        val meanY = sumY / n
        val ssTot = points.sumOf { (it.second - meanY).pow(2) }
        val ssRes = points.sumOf { (it.second - (slope * it.first + intercept)).pow(2) }

        val r2 = if (ssTot == 0.0) 1.0 else 1.0 - (ssRes / ssTot)

        return LinearFit(slope, intercept, r2.coerceIn(0.0, 1.0))
    }

    fun predict(x: Double, fit: LinearFit): Double =
        fit.slope * x + fit.intercept
}
