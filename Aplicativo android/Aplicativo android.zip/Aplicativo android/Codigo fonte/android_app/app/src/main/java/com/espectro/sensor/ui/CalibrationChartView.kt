package com.espectro.sensor.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import com.espectro.sensor.data.LinearFit
import com.espectro.sensor.model.CalibPoint
import kotlin.math.min

class CalibrationChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : android.view.View(context, attrs) {

    private var points: List<CalibPoint> = emptyList()
    private var fit: LinearFit? = null

    private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.DKGRAY
        strokeWidth = 2f
    }
    private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1565C0")
        style = Paint.Style.FILL
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E65100")
        strokeWidth = 3f
        style = Paint.Style.STROKE
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 28f
    }

    fun setData(points: List<CalibPoint>, fit: LinearFit?) {
        this.points = points
        this.fit = fit
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (points.isEmpty()) {
            canvas.drawText("Adicione pontos para ver o gráfico", 24f, height / 2f, textPaint)
            return
        }

        val padL = 80f
        val padB = 70f
        val padT = 40f
        val padR = 30f
        val w = width - padL - padR
        val h = height - padT - padB

        val xs = points.map { it.full.toFloat() }
        val ys = points.map { it.concentration.toFloat() }
        var minX = xs.minOrNull() ?: 0f
        var maxX = xs.maxOrNull() ?: 1f
        var minY = ys.minOrNull() ?: 0f
        var maxY = ys.maxOrNull() ?: 1f
        if (minX == maxX) maxX += 1f
        if (minY == maxY) maxY += 1f
        minX *= 0.95f
        maxX *= 1.05f
        minY = min(0f, minY * 0.95f)
        maxY *= 1.05f

        fun mapX(x: Float) = padL + (x - minX) / (maxX - minX) * w
        fun mapY(y: Float) = padT + h - (y - minY) / (maxY - minY) * h

        canvas.drawLine(padL, padT + h, padL + w, padT + h, axisPaint)
        canvas.drawLine(padL, padT, padL, padT + h, axisPaint)

        canvas.drawText("Full", padL + w / 2 - 20f, height - 16f, textPaint)
        canvas.save()
        canvas.rotate(-90f, 20f, padT + h / 2)
        canvas.drawText("Concentração", 20f, padT + h / 2, textPaint)
        canvas.restore()

        fit?.let { f ->
            val y1 = (f.slope * minX + f.intercept).toFloat()
            val y2 = (f.slope * maxX + f.intercept).toFloat()
            canvas.drawLine(mapX(minX), mapY(y1), mapX(maxX), mapY(y2), linePaint)
        }

        points.forEach { p ->
            val cx = mapX(p.full.toFloat())
            val cy = mapY(p.concentration.toFloat())
            canvas.drawCircle(cx, cy, 10f, pointPaint)
        }

        fit?.let { f ->
            canvas.drawText(
                "R² = ${"%.4f".format(f.rSquared)}",
                padL + 8f,
                padT + 28f,
                textPaint
            )
        }
    }
}
