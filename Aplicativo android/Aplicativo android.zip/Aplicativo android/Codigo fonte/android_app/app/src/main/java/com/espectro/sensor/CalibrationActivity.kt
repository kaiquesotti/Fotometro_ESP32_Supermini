package com.espectro.sensor

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.espectro.sensor.data.CalibrationRepository
import com.espectro.sensor.data.CsvIO
import com.espectro.sensor.data.DraftRepository
import com.espectro.sensor.model.CalibPoint
import com.espectro.sensor.model.CalibrationCurve
import com.espectro.sensor.ui.CalibPointAdapter
import com.espectro.sensor.ui.CalibrationChartView
import com.espectro.sensor.util.BlePermissions
import com.espectro.sensor.util.FileShare
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class CalibrationActivity : AppCompatActivity() {

    private lateinit var ble: BleUartClient
    private lateinit var repo: CalibrationRepository
    private lateinit var draftRepo: DraftRepository
    private lateinit var adapter: CalibPointAdapter
    private lateinit var chart: CalibrationChartView

    private val points = mutableListOf<CalibPoint>()
    private var lastReading: SensorReading? = null
    private var editingCurveId: String? = null

    private lateinit var edtSampleName: TextInputEditText
    private lateinit var edtUnit: TextInputEditText
    private lateinit var edtConcentration: TextInputEditText
    private lateinit var txtBleStatus: TextView
    private lateinit var txtReading: TextView
    private lateinit var txtFitInfo: TextView
    private lateinit var btnMeasure: Button

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.all { it }) connectBle() else toast("Permissões necessárias")
    }

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.readText().orEmpty()
            val curve = CsvIO.importCalibration(text)
            if (curve == null) {
                toast("CSV inválido (mínimo 2 pontos)")
                return@registerForActivityResult
            }
            loadCurveIntoUi(curve)
            persistDraft()
            toast("Calibração importada: ${curve.name}")
        } catch (e: Exception) {
            toast("Erro ao importar: ${e.message}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calibration)

        repo = CalibrationRepository(this)
        draftRepo = DraftRepository(this)
        edtSampleName = findViewById(R.id.edtSampleName)
        edtUnit = findViewById(R.id.edtUnit)
        edtConcentration = findViewById(R.id.edtConcentration)
        txtBleStatus = findViewById(R.id.txtBleStatus)
        txtReading = findViewById(R.id.txtReading)
        txtFitInfo = findViewById(R.id.txtFitInfo)
        btnMeasure = findViewById(R.id.btnMeasure)
        chart = findViewById(R.id.chart)

        findViewById<MaterialToolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }

        adapter = CalibPointAdapter { index ->
            points.removeAt(index)
            refreshUi()
            persistDraft()
        }
        findViewById<RecyclerView>(R.id.listPoints).apply {
            layoutManager = LinearLayoutManager(this@CalibrationActivity)
            adapter = this@CalibrationActivity.adapter
        }

        loadDraftOrDefault()

        ble = BleUartClient(
            context = this,
            onStatus = { runOnUiThread { txtBleStatus.text = it } },
            onReady = { runOnUiThread { btnMeasure.isEnabled = true } },
            onReading = { reading ->
                runOnUiThread {
                    lastReading = reading
                    txtReading.text =
                        "Full: ${reading.full}  |  IR: ${reading.ir}  |  Lux: ${"%.2f".format(reading.lux)}"
                    persistDraft()
                }
            },
            onError = { runOnUiThread { toast(it) } },
            onDisconnected = {
                runOnUiThread {
                    btnMeasure.isEnabled = false
                    persistDraft()
                    toast("Bluetooth caiu — pontos do rascunho estão salvos no celular")
                }
            }
        )

        findViewById<Button>(R.id.btnNewCurve).setOnClickListener { confirmNewCurve() }
        findViewById<Button>(R.id.btnConnect).setOnClickListener { connectBle() }
        btnMeasure.setOnClickListener { ble.requestMeasure() }
        findViewById<Button>(R.id.btnAddPoint).setOnClickListener { addPoint() }
        findViewById<Button>(R.id.btnSaveCurve).setOnClickListener { saveCurve() }
        findViewById<Button>(R.id.btnExport).setOnClickListener { exportCsv() }
        findViewById<Button>(R.id.btnImport).setOnClickListener {
            importLauncher.launch(arrayOf("text/*", "text/csv", "application/csv", "*/*"))
        }

        refreshUi()
    }

    private fun loadDraftOrDefault() {
        val draft = draftRepo.loadCalibrationDraft()
        if (draft != null && draft.points.isNotEmpty()) {
            edtSampleName.setText(draft.sampleName)
            edtUnit.setText(draft.unit)
            editingCurveId = null
            points.clear()
            points.addAll(draft.points)
            if (draft.lastFull != null) {
                lastReading = SensorReading(
                    draft.lastIr ?: 0,
                    draft.lastFull!!,
                    draft.lastVisible ?: 0,
                    draft.lastLux ?: 0.0
                )
                txtReading.text =
                    "Full: ${draft.lastFull}  (última leitura recuperada)"
            }
            toast("Rascunho da calibração restaurado")
        } else {
            val defaultName =
                "Amostra ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}"
            edtSampleName.setText(defaultName)
        }
    }

    private fun persistDraft() {
        val r = lastReading
        draftRepo.saveCalibrationDraft(
            sampleName = edtSampleName.text?.toString().orEmpty(),
            unit = edtUnit.text?.toString().orEmpty(),
            points = points.toList(),
            editingCurveId = editingCurveId,
            lastFull = r?.full,
            lastIr = r?.ir,
            lastVisible = r?.visible,
            lastLux = r?.lux
        )
    }

    private fun connectBle() {
        btnMeasure.isEnabled = false
        val missing = BlePermissions.missing(this)
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
            return
        }
        ble.reconnectLastDevice()
    }

    private fun addPoint() {
        val reading = lastReading
        if (reading == null) {
            toast("Toque em Medir Full antes")
            return
        }
        val conc = edtConcentration.text?.toString()?.trim()?.replace(',', '.')?.toDoubleOrNull()
        if (conc == null) {
            toast("Informe a concentração conhecida")
            return
        }
        points.add(
            CalibPoint(
                full = reading.full,
                concentration = conc,
                ir = reading.ir,
                visible = reading.visible,
                lux = reading.lux
            )
        )
        refreshUi()
        persistDraft()
        toast("Ponto adicionado (salvo no rascunho)")
    }

    private fun refreshUi() {
        adapter.setItems(points)
        val fit = CalibrationCurve(name = "", points = points).fit
        chart.setData(points, fit)
        txtFitInfo.text = if (fit != null) {
            "R² = ${"%.4f".format(fit.rSquared)}  |  ${fit.equationText()}"
        } else {
            "R²: — (adicione pelo menos 2 pontos)"
        }
    }

    private fun saveCurve() {
        val name = edtSampleName.text?.toString()?.trim().orEmpty()
        if (name.isEmpty()) {
            toast("Dê um nome à amostra")
            return
        }
        if (points.size < 2) {
            toast("Mínimo 2 pontos para salvar")
            return
        }
        // Sempre cria uma curva NOVA no acervo (não sobrescreve a anterior)
        val curve = CalibrationCurve(
            id = UUID.randomUUID().toString(),
            name = name,
            points = points.toList(),
            unit = edtUnit.text?.toString()?.trim().orEmpty()
        )
        repo.saveCalibration(curve)
        val total = repo.listCalibrations().size
        toast("Curva \"$name\" salva ($total no total). Anteriores mantidas.")
        startNewCurve(askConfirm = false)
    }

    private fun confirmNewCurve() {
        if (points.isNotEmpty()) {
            AlertDialog.Builder(this)
                .setTitle(R.string.new_calibration_curve)
                .setMessage(R.string.new_curve_confirm)
                .setPositiveButton(android.R.string.ok) { _, _ -> startNewCurve(askConfirm = false) }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        } else {
            startNewCurve(askConfirm = false)
        }
    }

    private fun startNewCurve(askConfirm: Boolean) {
        if (askConfirm) {
            confirmNewCurve()
            return
        }
        editingCurveId = null
        points.clear()
        lastReading = null
        txtReading.text = "Full: —"
        edtConcentration.text?.clear()
        val defaultName =
            "Amostra ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}"
        edtSampleName.setText(defaultName)
        refreshUi()
        draftRepo.clearCalibrationDraft()
        persistDraft()
    }

    private fun exportCsv() {
        if (points.size < 2) {
            toast("Mínimo 2 pontos para exportar")
            return
        }
        val name = edtSampleName.text?.toString()?.trim().orEmpty().ifEmpty { "calibracao" }
        val curve = CalibrationCurve(
            id = editingCurveId ?: "draft",
            name = name,
            points = points.toList(),
            unit = edtUnit.text?.toString()?.trim().orEmpty()
        )
        val safe = name.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        FileShare.shareCsv(this, "calibracao_${safe}.csv", CsvIO.exportCalibration(curve))
    }

    private fun loadCurveIntoUi(curve: CalibrationCurve) {
        // Importar = cópia para editar; ao salvar gera nova curva (não substitui a importada)
        editingCurveId = null
        edtSampleName.setText("${curve.name} (cópia)")
        edtUnit.setText(curve.unit)
        points.clear()
        points.addAll(curve.points)
        refreshUi()
    }

    override fun onPause() {
        super.onPause()
        persistDraft()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        persistDraft()
        ble.disconnect()
        super.onDestroy()
    }
}
