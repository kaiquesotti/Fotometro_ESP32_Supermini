package com.espectro.sensor.model

import com.espectro.sensor.data.LinearFit
import com.espectro.sensor.data.LinearRegression
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class CalibPoint(
    val full: Int,
    val concentration: Double,
    val ir: Int = 0,
    val visible: Int = 0,
    val lux: Double = 0.0,
    val timestampMs: Long = System.currentTimeMillis()
)

data class CalibrationCurve(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val points: List<CalibPoint>,
    val createdAtMs: Long = System.currentTimeMillis(),
    val unit: String = ""
) {
    val fit: LinearFit? get() = LinearRegression.fit(
        points.map { it.full.toDouble() to it.concentration }
    )

    fun predictConcentration(full: Int): Double? =
        fit?.let { LinearRegression.predict(full.toDouble(), it) }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("createdAtMs", createdAtMs)
        .put("unit", unit)
        .put(
            "points",
            JSONArray().apply {
                points.forEach { p ->
                    put(
                        JSONObject()
                            .put("full", p.full)
                            .put("concentration", p.concentration)
                            .put("ir", p.ir)
                            .put("visible", p.visible)
                            .put("lux", p.lux)
                            .put("timestampMs", p.timestampMs)
                    )
                }
            }
        )

    companion object {
        fun fromJson(o: JSONObject): CalibrationCurve {
            val arr = o.getJSONArray("points")
            val points = mutableListOf<CalibPoint>()
            for (i in 0 until arr.length()) {
                val p = arr.getJSONObject(i)
                points.add(
                    CalibPoint(
                        full = p.getInt("full"),
                        concentration = p.getDouble("concentration"),
                        ir = p.optInt("ir", 0),
                        visible = p.optInt("visible", 0),
                        lux = p.optDouble("lux", 0.0),
                        timestampMs = p.optLong("timestampMs", 0L)
                    )
                )
            }
            return CalibrationCurve(
                id = o.getString("id"),
                name = o.getString("name"),
                points = points,
                createdAtMs = o.optLong("createdAtMs", System.currentTimeMillis()),
                unit = o.optString("unit", "")
            )
        }
    }
}

data class SampleMeasurement(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val calibrationId: String,
    val calibrationName: String,
    val full: Int,
    val ir: Int,
    val visible: Int,
    val lux: Double,
    val concentration: Double,
    val timestampMs: Long = System.currentTimeMillis()
)
