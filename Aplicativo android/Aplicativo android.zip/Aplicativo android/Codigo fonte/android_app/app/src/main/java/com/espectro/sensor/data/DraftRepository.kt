package com.espectro.sensor.data

import android.content.Context
import com.espectro.sensor.model.CalibPoint
import org.json.JSONArray
import org.json.JSONObject

/** Rascunho de calibração — sobrevive a queda do BLE ou fechar a tela. */
class DraftRepository(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("espectro_draft", Context.MODE_PRIVATE)

    fun saveCalibrationDraft(
        sampleName: String,
        unit: String,
        points: List<CalibPoint>,
        editingCurveId: String?,
        lastFull: Int?,
        lastIr: Int?,
        lastVisible: Int?,
        lastLux: Double?
    ) {
        val o = JSONObject()
            .put("sampleName", sampleName)
            .put("unit", unit)
            .put("editingCurveId", editingCurveId ?: "")
            .put(
                "points",
                JSONArray().apply {
                    points.forEach { p ->
                        put(
                            JSONObject()
                                .put("full", p.full)
                                .put("concentration", p.concentration)
                                .put("ir", p.ir)
                                .put("visible", p.visible)
                                .put("lux", p.lux)
                        )
                    }
                }
            )
        if (lastFull != null) {
            o.put("lastFull", lastFull)
            o.put("lastIr", lastIr ?: 0)
            o.put("lastVisible", lastVisible ?: 0)
            o.put("lastLux", lastLux ?: 0.0)
        }
        prefs.edit().putString(KEY_CALIB, o.toString()).apply()
    }

    data class CalibrationDraft(
        val sampleName: String,
        val unit: String,
        val points: List<CalibPoint>,
        val editingCurveId: String?,
        val lastFull: Int?,
        val lastIr: Int?,
        val lastVisible: Int?,
        val lastLux: Double?
    )

    fun loadCalibrationDraft(): CalibrationDraft? {
        val raw = prefs.getString(KEY_CALIB, null) ?: return null
        return try {
            val o = JSONObject(raw)
            val points = mutableListOf<CalibPoint>()
            val arr = o.getJSONArray("points")
            for (i in 0 until arr.length()) {
                val p = arr.getJSONObject(i)
                points.add(
                    CalibPoint(
                        full = p.getInt("full"),
                        concentration = p.getDouble("concentration"),
                        ir = p.optInt("ir", 0),
                        visible = p.optInt("visible", 0),
                        lux = p.optDouble("lux", 0.0)
                    )
                )
            }
            CalibrationDraft(
                sampleName = o.optString("sampleName", ""),
                unit = o.optString("unit", ""),
                points = points,
                editingCurveId = o.optString("editingCurveId", "").ifEmpty { null },
                lastFull = if (o.has("lastFull")) o.getInt("lastFull") else null,
                lastIr = if (o.has("lastIr")) o.getInt("lastIr") else null,
                lastVisible = if (o.has("lastVisible")) o.getInt("lastVisible") else null,
                lastLux = if (o.has("lastLux")) o.getDouble("lastLux") else null
            )
        } catch (_: Exception) {
            null
        }
    }

    fun clearCalibrationDraft() {
        prefs.edit().remove(KEY_CALIB).apply()
    }

    fun saveMeasureSession(sessionName: String, measureCounter: Int, curveId: String?) {
        prefs.edit()
            .putString(KEY_SESSION, sessionName)
            .putInt(KEY_COUNTER, measureCounter)
            .putString(KEY_CURVE_ID, curveId ?: "")
            .apply()
    }

    fun loadMeasureSession(): Triple<String, Int, String?> {
        val name = prefs.getString(KEY_SESSION, "") ?: ""
        val counter = prefs.getInt(KEY_COUNTER, 1)
        val curveId = prefs.getString(KEY_CURVE_ID, "")?.ifEmpty { null }
        return Triple(name, counter, curveId)
    }

    companion object {
        private const val KEY_CALIB = "calib_draft"
        private const val KEY_SESSION = "measure_session"
        private const val KEY_COUNTER = "measure_counter"
        private const val KEY_CURVE_ID = "measure_curve_id"
    }
}
