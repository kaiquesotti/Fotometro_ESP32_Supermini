package com.espectro.sensor

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import java.util.UUID

@SuppressLint("MissingPermission")
class BleUartClient(
    private val context: Context,
    private val deviceNamePrefix: String = "Espectro-TSL",
    private val onStatus: (String) -> Unit,
    private val onReady: () -> Unit,
    private val onReading: (SensorReading) -> Unit,
    private val onError: (String) -> Unit,
    private val onDisconnected: () -> Unit = {}
) {
    companion object {
        val SERVICE_UUID: UUID = UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
        val RX_UUID: UUID = UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E")
        val TX_UUID: UUID = UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E")
        val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val adapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private var gatt: BluetoothGatt? = null
    private var lastDevice: BluetoothDevice? = null
    private var txCharacteristic: BluetoothGattCharacteristic? = null
    private var rxCharacteristic: BluetoothGattCharacteristic? = null
    private val lineBuffer = StringBuilder()

    private var isScanning = false
    private var isConnecting = false

    var isConnected: Boolean = false
        private set

    /** true somente após notificações BLE habilitadas — aí "Medir" funciona */
    var isReady: Boolean = false
        private set

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            if (!isTargetDevice(result)) return
            stopScan()
            connectDevice(result.device, deviceLabel(result))
        }

        override fun onScanFailed(errorCode: Int) {
            isScanning = false
            onError("Falha na busca BLE (código $errorCode)")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    onError("Conexão recusada ($status). Desemparelhe o ESP em Configurações → Bluetooth.")
                    disconnect()
                    return
                }
                isConnecting = false
                lastDevice = gatt.device
                onStatus("Conectado. Configurando…")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    gatt.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH)
                }
                gatt.requestMtu(512)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                isConnected = false
                isReady = false
                isConnecting = false
                txCharacteristic = null
                rxCharacteristic = null
                onStatus("Desconectado — toque em Reconectar")
                onDisconnected()
            }
        }

        override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
            gatt.discoverServices()
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                onError("Serviços não encontrados ($status)")
                return
            }
            val service = gatt.getService(SERVICE_UUID)
            txCharacteristic = service?.getCharacteristic(TX_UUID)
            rxCharacteristic = service?.getCharacteristic(RX_UUID)
            if (txCharacteristic == null || rxCharacteristic == null) {
                onError("UART BLE não encontrado. Gravou tsl2591_ble.ino?")
                return
            }
            isConnected = true
            gatt.setCharacteristicNotification(txCharacteristic, true)
            val cccd = txCharacteristic!!.getDescriptor(CCCD_UUID)
                ?: run {
                    onError("Descriptor CCCD ausente")
                    return
                }
            cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            val ok = gatt.writeDescriptor(cccd)
            if (!ok) {
                onError("Falha ao habilitar notificações")
            }
        }

        override fun onDescriptorWrite(
            gatt: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            status: Int
        ) {
            if (descriptor.uuid != CCCD_UUID) return
            if (status == BluetoothGatt.GATT_SUCCESS) {
                isReady = true
                onStatus("Pronto — toque em Medir")
                onReady()
            } else {
                onError("Notificações BLE falharam ($status)")
            }
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            val bytes = characteristic.value ?: return
            handleIncoming(String(bytes, Charsets.UTF_8))
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            handleIncoming(String(value, Charsets.UTF_8))
        }

        override fun onCharacteristicWrite(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                onError("Falha ao enviar comando ($status)")
            }
        }
    }

    private fun handleIncoming(text: String) {
        if (text.startsWith("ERR")) {
            onError(
                if (text.contains("SENSOR")) "Sensor TSL2591 não responde no ESP"
                else text
            )
            return
        }
        appendAndParse(text)
    }

    private fun connectDevice(device: BluetoothDevice, label: String) {
        disconnectGattOnly()
        lastDevice = device
        isConnecting = true
        isReady = false
        onStatus("Conectando a $label…")

        gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } else {
            device.connectGatt(context, false, gattCallback)
        }
    }

    /** Reconecta ao último ESP sem nova busca (mais rápido após queda). */
    fun reconnectLastDevice() {
        val device = lastDevice
        if (device != null) {
            connectDevice(device, device.name ?: deviceNamePrefix)
            mainHandler.postDelayed({ checkConnectTimeout() }, 15_000)
        } else {
            startScanAndConnect()
        }
    }

    private fun isTargetDevice(result: ScanResult): Boolean {
        val name = deviceLabel(result)
        if (name.startsWith(deviceNamePrefix, ignoreCase = true)) return true
        val uuids = result.scanRecord?.serviceUuids.orEmpty()
        if (uuids.any { it.uuid == SERVICE_UUID }) return true
        return false
    }

    private fun deviceLabel(result: ScanResult): String {
        return result.scanRecord?.deviceName
            ?: result.device.name
            ?: result.device.address
            ?: "desconhecido"
    }

    private fun deviceLabel(name: String?): String = name ?: "ESP32"

    private fun tryConnectBonded(): Boolean {
        val bonded = adapter?.bondedDevices.orEmpty()
        for (device in bonded) {
            val name = device.name ?: continue
            if (name.startsWith(deviceNamePrefix, ignoreCase = true)) {
                onStatus("Usando aparelho pareado: $name")
                connectDevice(device, name)
                return true
            }
        }
        return false
    }

    fun startScanAndConnect() {
        if (adapter == null || !adapter.isEnabled) {
            onError("Ligue o Bluetooth do celular")
            return
        }
        disconnect()
        isConnecting = false
        isReady = false

        if (tryConnectBonded()) {
            mainHandler.postDelayed({ checkConnectTimeout() }, 15_000)
            return
        }

        startBleScan()
    }

    private fun startBleScan() {
        onStatus("Buscando $deviceNamePrefix…")

        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(SERVICE_UUID))
            .build()

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        isScanning = true
        adapter?.bluetoothLeScanner?.startScan(listOf(filter), settings, scanCallback)

        mainHandler.postDelayed({
            if (!isConnected && !isConnecting) {
                stopScan()
                onStatus("Busca ampla…")
                isScanning = true
                adapter?.bluetoothLeScanner?.startScan(scanCallback)
                mainHandler.postDelayed({ checkConnectTimeout() }, 12_000)
            }
        }, 12_000)

        mainHandler.postDelayed({ checkConnectTimeout() }, 25_000)
    }

    private fun checkConnectTimeout() {
        if (!isConnected && !isConnecting) {
            stopScan()
            onError(
                "Não conectou. Desemparelhe Espectro-TSL em Bluetooth do celular, " +
                    "reinicie o ESP e tente de novo pelo app."
            )
        }
    }

    private fun stopScan() {
        if (!isScanning) return
        isScanning = false
        adapter?.bluetoothLeScanner?.stopScan(scanCallback)
    }

    fun requestMeasure() {
        val ch = rxCharacteristic
        val g = gatt
        if (!isReady || ch == null || g == null) {
            onError("Aguarde 'Pronto — toque em Medir'")
            return
        }

        val payload = "M".toByteArray(Charsets.UTF_8)
        val writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

        val writeOk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            g.writeCharacteristic(ch, payload, writeType) == BluetoothGatt.GATT_SUCCESS
        } else {
            @Suppress("DEPRECATION")
            ch.value = payload
            ch.writeType = writeType
            @Suppress("DEPRECATION")
            g.writeCharacteristic(ch)
        }

        if (!writeOk) {
            onError("Não foi possível enviar comando de medição")
        } else {
            onStatus("Medindo…")
        }
    }

    private fun disconnectGattOnly() {
        stopScan()
        gatt?.close()
        gatt = null
        txCharacteristic = null
        rxCharacteristic = null
        isConnected = false
        isReady = false
        lineBuffer.clear()
    }

    fun disconnect() {
        mainHandler.removeCallbacksAndMessages(null)
        disconnectGattOnly()
        isConnecting = false
    }

    private fun appendAndParse(chunk: String) {
        lineBuffer.append(chunk)
        var idx = lineBuffer.indexOf("\n")
        while (idx >= 0) {
            val line = lineBuffer.substring(0, idx).trim()
            lineBuffer.delete(0, idx + 1)
            if (line.isNotEmpty()) {
                SensorReading.parse(line)?.let { onReading(it) }
            }
            idx = lineBuffer.indexOf("\n")
        }
        val rest = lineBuffer.toString().trim()
        if (rest.isNotEmpty()) {
            SensorReading.parse(rest)?.let {
                onReading(it)
                lineBuffer.clear()
            }
        }
    }
}
