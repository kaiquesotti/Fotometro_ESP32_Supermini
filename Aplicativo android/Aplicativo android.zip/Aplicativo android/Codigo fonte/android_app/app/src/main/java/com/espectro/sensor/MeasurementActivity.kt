package com.espectro.sensor

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.espectro.sensor.data.CalibrationRepository
import com.espectro.sensor.data.CsvIO
import com.espectro.sensor.data.DraftRepository
import com.espectro.sensor.model.CalibrationCurve
import com.espectro.sensor.model.SampleMeasurement
import com.espectro.sensor.ui.MeasurementListAdapter
import com.espectro.sensor.util.BlePermissions
import com.espectro.sensor.util.FileShare
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MeasurementActivity : AppCompatActivity() {

    private lateinit var ble: BleUartClient
    private lateinit var repo: CalibrationRepository
    private lateinit var draftRepo: DraftRepository
    private lateinit var listAdapter: MeasurementListAdapter

    private var curves = listOf<CalibrationCurve>()
    private var selectedCurve: CalibrationCurve? = null
    private var measureCounter = 1

    private lateinit var spinner: Spinner
    private lateinit var txtCurveInfo: TextView
    private lateinit var txtBleStatus: TextView
    private lateinit var txtResult: TextView
    private lateinit var edtSessionName: TextInputEditText
    private lateinit var edtMeasureName: TextInputEditText
    private lateinit var btnMeasure: Button

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.all { it }) connectBle() else toast("Permissões necessárias")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_measurement)

        repo = CalibrationRepository(this)
        draftRepo = DraftRepository(this)
        spinner = findViewById(R.id.spinnerCurves)
        txtCurveInfo = findViewById(R.id.txtCurveInfo)
        txtBleStatus = findViewById(R.id.txtBleStatus)
        txtResult = findViewById(R.id.txtResult)
        edtSessionName = findViewById(R.id.edtSessionName)
        edtMeasureName = findViewById(R.id.edtMeasureName)
        btnMeasure = findViewById(R.id.btnMeasure)

        findViewById<MaterialToolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }

        val (savedSession, savedCounter, _) = draftRepo.loadMeasureSession()
        if (savedSession.isNotEmpty()) {
            edtSessionName.setText(savedSession)
            measureCounter = savedCounter
        } else {
            edtSessionName.setText(
                "Sessão ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}"
            )
        }
        edtMeasureName.setText("Medida ${"%03d".format(measureCounter)}")

        listAdapter = MeasurementListAdapter()
        findViewById<RecyclerView>(R.id.listMeasures).apply {
            layoutManager = LinearLayoutManager(this@MeasurementActivity)
            adapter = listAdapter
        }

        ble = BleUartClient(
            context = this,
            onStatus = { runOnUiThread { txtBleStatus.text = it } },
            onReady = { runOnUiThread { updateMeasureButton() } },
            onReading = { reading -> runOnUiThread { onSensorReading(reading) } },
            onError = { runOnUiThread { toast(it) } },
            onDisconnected = {
                runOnUiThread {
                    updateMeasureButton()
                    persistSessionDraft()
                    toast("Bluetooth caiu — medições já salvas permanecem na lista")
                }
            }
        )

        findViewById<Button>(R.id.btnConnect).setOnClickListener { connectBle() }
        btnMeasure.setOnClickListener {
            edtMeasureName.setText("Medida ${"%03d".format(measureCounter)}")
            ble.requestMeasure()
        }
        findViewById<Button>(R.id.btnExport).setOnClickListener { exportSession() }

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                selectedCurve = curves.getOrNull(pos)
                updateCurveInfo()
                loadSessionMeasures()
                persistSessionDraft()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        reloadCurves()
    }

    private fun reloadCurves() {
        curves = repo.listCalibrations()
        if (curves.isEmpty()) {
            spinner.adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("Nenhuma curva — faça calibração antes")
            )
            selectedCurve = null
            txtCurveInfo.text = "Crie uma curva no modo Calibração"
            btnMeasure.isEnabled = false
            return
        }
        val names = curves.map {
            "${it.name} (R²=${it.fit?.rSquared?.let { r -> "%.3f".format(r) } ?: "?"})"
        }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)

        val (_, _, savedCurveId) = draftRepo.loadMeasureSession()
        val index = savedCurveId?.let { id -> curves.indexOfFirst { it.id == id } } ?: 0
        val pick = if (index >= 0) index else 0
        spinner.setSelection(pick)
        selectedCurve = curves[pick]
        updateCurveInfo()
        loadSessionMeasures()
    }

    private fun updateCurveInfo() {
        val c = selectedCurve ?: return
        val fit = c.fit
        val unit = if (c.unit.isNotEmpty()) " ${c.unit}" else ""
        txtCurveInfo.text = if (fit != null) {
            "${fit.equationText()}  |  R²=${"%.4f".format(fit.rSquared)}$unit"
        } else {
            "Curva sem regressão válida"
        }
        updateMeasureButton()
    }

    private fun updateMeasureButton() {
        btnMeasure.isEnabled = ble.isReady && selectedCurve?.fit != null
    }

    private fun connectBle() {
        btnMeasure.isEnabled = false
        val missing = BlePermissions.missing(this)
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
            return
        }
        ble.reconnectLastDevice()
    }

    private fun onSensorReading(reading: SensorReading) {
        val curve = selectedCurve
        val fit = curve?.fit
        if (curve == null || fit == null) {
            toast("Selecione uma curva válida")
            return
        }
        val conc = curve.predictConcentration(reading.full)
        if (conc == null) {
            toast("Erro no cálculo")
            return
        }

        val measureName = edtMeasureName.text?.toString()?.trim().orEmpty().ifEmpty {
            "Medida ${"%03d".format(measureCounter)}"
        }

        val unit = if (curve.unit.isNotEmpty()) " ${curve.unit}" else ""
        txtResult.text =
            "$measureName\nFull: ${reading.full}  →  concentração: ${"%.4g".format(conc)}$unit"

        val m = SampleMeasurement(
            name = measureName,
            calibrationId = curve.id,
            calibrationName = curve.name,
            full = reading.full,
            ir = reading.ir,
            visible = reading.visible,
            lux = reading.lux,
            concentration = conc
        )
        repo.saveMeasurement(m)
        loadSessionMeasures()
        measureCounter++
        edtMeasureName.setText("Medida ${"%03d".format(measureCounter)}")
        persistSessionDraft()
        toast("Medida salva no celular")
    }

    private fun loadSessionMeasures() {
        val curveId = selectedCurve?.id ?: return
        listAdapter.setItems(repo.listMeasurements(curveId))
    }

    private fun persistSessionDraft() {
        draftRepo.saveMeasureSession(
            sessionName = edtSessionName.text?.toString().orEmpty(),
            measureCounter = measureCounter,
            curveId = selectedCurve?.id
        )
    }

    private fun exportSession() {
        val curve = selectedCurve
        if (curve == null) {
            toast("Sem curva selecionada")
            return
        }
        val items = listAdapter.items()
        if (items.isEmpty()) {
            toast("Nenhuma medida para exportar")
            return
        }
        val session = edtSessionName.text?.toString()?.trim().orEmpty().ifEmpty { "sessao" }
        val csv = CsvIO.exportMeasurements(session, curve.name, curve.id, items)
        val safe = session.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        FileShare.shareCsv(this, "medidas_${safe}.csv", csv)
    }

    override fun onPause() {
        super.onPause()
        persistSessionDraft()
    }

    override fun onResume() {
        super.onResume()
        loadSessionMeasures()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        persistSessionDraft()
        ble.disconnect()
        super.onDestroy()
    }
}
