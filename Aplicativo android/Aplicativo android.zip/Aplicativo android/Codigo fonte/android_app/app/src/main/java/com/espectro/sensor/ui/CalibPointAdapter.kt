package com.espectro.sensor.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.espectro.sensor.R
import com.espectro.sensor.model.CalibPoint
import java.util.Locale

class CalibPointAdapter(
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<CalibPointAdapter.VH>() {

    private val items = mutableListOf<CalibPoint>()

    fun setItems(newItems: List<CalibPoint>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_calib_point, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        holder.txt.text = String.format(
            Locale.getDefault(),
            "#%d — Full: %d  |  conc: %s",
            position + 1,
            p.full,
            p.concentration.toString()
        )
        holder.btnDelete.setOnClickListener { onDelete(position) }
    }

    override fun getItemCount() = items.size

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val txt: TextView = view.findViewById(R.id.txtItem)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDelete)
    }
}
