package com.espectro.sensor.data

import com.espectro.sensor.model.CalibPoint
import com.espectro.sensor.model.CalibrationCurve
import com.espectro.sensor.model.SampleMeasurement
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object CsvIO {

    private val isoFmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)

    fun exportCalibration(curve: CalibrationCurve): String {
        val fit = curve.fit
        val sb = StringBuilder()
        sb.appendLine("# Espectro TSL - Calibracao")
        sb.appendLine("type,calibration")
        sb.appendLine("name,${csvEscape(curve.name)}")
        sb.appendLine("id,${curve.id}")
        sb.appendLine("created_at,${isoFmt.format(Date(curve.createdAtMs))}")
        sb.appendLine("unit,${csvEscape(curve.unit)}")
        sb.appendLine("variable_x,full")
        sb.appendLine("variable_y,concentration")
        if (fit != null) {
            sb.appendLine("slope,${fit.slope}")
            sb.appendLine("intercept,${fit.intercept}")
            sb.appendLine("r_squared,${fit.rSquared}")
            sb.appendLine("equation,${csvEscape(fit.equationText())}")
        }
        sb.appendLine()
        sb.appendLine("point_index,full,concentration,ir,visible,lux")
        curve.points.forEachIndexed { i, p ->
            sb.appendLine(
                "${i + 1},${p.full},${p.concentration},${p.ir},${p.visible},${p.lux}"
            )
        }
        return sb.toString()
    }

    fun importCalibration(text: String): CalibrationCurve? {
        var name = "Importada"
        var unit = ""
        var id = UUID.randomUUID().toString()
        val points = mutableListOf<CalibPoint>()
        var headerFound = false

        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) return@forEach

            val cols = parseCsvLine(line)
            if (cols.isEmpty()) return@forEach

            when (cols[0].lowercase()) {
                "name" -> if (cols.size > 1) name = cols[1]
                "unit" -> if (cols.size > 1) unit = cols[1]
                "id" -> if (cols.size > 1) id = cols[1]
                "point_index" -> {
                    headerFound = true
                    return@forEach
                }
                "full" -> if (cols.size > 1 && cols[1].equals("concentration", true)) {
                    headerFound = true
                    return@forEach
                }
            }

            val full = cols.getOrNull(if (cols[0].toIntOrNull() != null) 1 else 0)?.toIntOrNull()
                ?: cols.getOrNull(0)?.toIntOrNull()
            val concCol = when {
                cols[0].toIntOrNull() != null -> 2
                cols[0].equals("full", true) -> return@forEach
                else -> 1
            }
            val conc = cols.getOrNull(concCol)?.replace(',', '.')?.toDoubleOrNull()

            if (full != null && conc != null && (headerFound || cols[0].toIntOrNull() != null)) {
                points.add(
                    CalibPoint(
                        full = full,
                        concentration = conc,
                        ir = cols.getOrNull(concCol + 1)?.toIntOrNull() ?: 0,
                        visible = cols.getOrNull(concCol + 2)?.toIntOrNull() ?: 0,
                        lux = cols.getOrNull(concCol + 3)?.replace(',', '.')?.toDoubleOrNull() ?: 0.0
                    )
                )
            }
        }

        if (points.size < 2) return null
        return CalibrationCurve(id = id, name = name, points = points, unit = unit)
    }

    fun exportMeasurements(
        sessionName: String,
        calibrationName: String,
        calibrationId: String,
        items: List<SampleMeasurement>
    ): String {
        val sb = StringBuilder()
        sb.appendLine("# Espectro TSL - Medidas")
        sb.appendLine("type,measurements")
        sb.appendLine("session_name,${csvEscape(sessionName)}")
        sb.appendLine("calibration_name,${csvEscape(calibrationName)}")
        sb.appendLine("calibration_id,$calibrationId")
        sb.appendLine("exported_at,${isoFmt.format(Date())}")
        sb.appendLine()
        sb.appendLine("measurement_name,full,ir,visible,lux,concentration,timestamp")
        items.forEach { m ->
            sb.appendLine(
                "${csvEscape(m.name)},${m.full},${m.ir},${m.visible},${m.lux}," +
                    "${m.concentration},${isoFmt.format(Date(m.timestampMs))}"
            )
        }
        return sb.toString()
    }

    private fun csvEscape(s: String): String {
        return if (s.contains(',') || s.contains('"')) {
            "\"${s.replace("\"", "\"\"")}\""
        } else s
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' -> {
                    if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                        sb.append('"')
                        i++
                    } else inQuotes = !inQuotes
                }
                c == ',' && !inQuotes -> {
                    result.add(sb.toString().trim())
                    sb.clear()
                }
                else -> sb.append(c)
            }
            i++
        }
        result.add(sb.toString().trim())
        return result
    }
}
