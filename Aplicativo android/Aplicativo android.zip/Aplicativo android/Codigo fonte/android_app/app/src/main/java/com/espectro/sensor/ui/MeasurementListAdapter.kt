package com.espectro.sensor.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.espectro.sensor.R
import com.espectro.sensor.model.SampleMeasurement
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MeasurementListAdapter : RecyclerView.Adapter<MeasurementListAdapter.VH>() {

    private val items = mutableListOf<SampleMeasurement>()
    private val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())

    fun setItems(newItems: List<SampleMeasurement>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    fun items(): List<SampleMeasurement> = items.toList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_measurement, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = items[position]
        holder.txt.text = String.format(
            Locale.getDefault(),
            "%s — conc: %s | Full: %d | %s",
            m.name,
            "%.4g".format(m.concentration),
            m.full,
            fmt.format(Date(m.timestampMs))
        )
    }

    override fun getItemCount() = items.size

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val txt: TextView = view.findViewById(R.id.txtItem)
    }
}
