package com.espectro.sensor

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.espectro.sensor.data.CalibrationRepository
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val repo = CalibrationRepository(this)

        findViewById<MaterialButton>(R.id.btnModeCalibration).setOnClickListener {
            startActivity(Intent(this, CalibrationActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnModeMeasure).setOnClickListener {
            startActivity(Intent(this, MeasurementActivity::class.java))
        }

        refreshCount(repo)
    }

    override fun onResume() {
        super.onResume()
        refreshCount(CalibrationRepository(this))
    }

    private fun refreshCount(repo: CalibrationRepository) {
        val n = repo.listCalibrations().size
        findViewById<TextView>(R.id.txtCalibCount).text = "Curvas salvas: $n"
    }
}
