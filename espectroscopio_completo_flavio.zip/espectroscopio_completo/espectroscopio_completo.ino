// Bibliotecas necessárias
#include <WiFi.h>
#include <WebServer.h>
#include <ArduinoJson.h>
#include <SPIFFS.h>

// Configurações da rede Wi-Fi (Modo Access Point)
const char* ssid = "ESP32_Espectroscopio_mini_C3";
const char* password = "123456789";

// Pinos - Adaptados para ESP32-C3 SuperMini
const int ledPin = 7;        // LED no GPIO7 (ESP32-C3 SuperMini)
const int ldrPin = 4;        // LDR no GPIO4 (ESP32-C3 SuperMini - entrada analógica)



// Variáveis globais
WebServer server(80);
bool ledStatus = false;      // Status do LED (ligado/desligado)
bool modoCalibracao = true;  // true = modo calibração, false = modo medida

// Estrutura para armazenar as medidas de calibração
struct Measurement {
  int ldrValue;
  float concentration;
  unsigned long timestamp;
};

// Estrutura para armazenar as medições (modo medida)
struct Medicao {
  int ldrValue;
  float calculatedConcentration;
  unsigned long timestamp;
};

// Usar array estático em vez de vector para evitar problemas de memória
#define MAX_MEASUREMENTS 50
Measurement measurements[MAX_MEASUREMENTS];
int measurementCount = 0;

#define MAX_MEDICOES 100
Medicao medicoes[MAX_MEDICOES];
int medicaoCount = 0;

// Variáveis para calibração
float calibracao_a = 0;  // Coeficiente angular
float calibracao_b = 0;  // Coeficiente linear
bool calibracaoAtiva = false;

// Função para ler o LDR e retornar a média de 3 leituras
int readLDRAverage() {
  long sum = 0;
  for (int i = 0; i < 3; i++) {
    // Configuração específica para ESP32-C3
    sum += analogRead(ldrPin);  // Le o valor do LDR
    delay(100); // Aumentado o atraso para estabilização
  }
  return sum / 3;
}

// Função para calcular a concentração baseada na calibração
float calculateConcentration(int ldrValue) {
  if (!calibracaoAtiva) {
    return -1; // Nao ha calibracao ativa
  }
  
  return calibracao_a * ldrValue + calibracao_b;
}

// Função para recalcular calibração com todos os pontos
void recalcularCalibracao() {
  if (measurementCount < 2) {
    calibracaoAtiva = false;
    return;
  }
  
  // Calcular média dos pontos para melhor precisão
  float sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
  
  for (int i = 0; i < measurementCount; i++) {
    float x = measurements[i].ldrValue;
    float y = measurements[i].concentration;
    
    sumX += x;
    sumY += y;
    sumXY += x * y;
    sumX2 += x * x;
  }
  
  float n = measurementCount;
  float denominador = n * sumX2 - sumX * sumX;
  
  if (denominador != 0) {
    calibracao_a = (n * sumXY - sumX * sumY) / denominador;
    calibracao_b = (sumY - calibracao_a * sumX) / n;
    calibracaoAtiva = true;
  } else {
    calibracaoAtiva = false;
  }
}

// Função para adicionar uma nova medida
bool addMeasurement(int ldrValue, float concentration) {
  if (measurementCount >= MAX_MEASUREMENTS) {
    return false; // Array cheio
  }
  
  measurements[measurementCount].ldrValue = ldrValue;
  measurements[measurementCount].concentration = concentration;
  measurements[measurementCount].timestamp = millis() / 1000; // timestamp em segundos
  measurementCount++;
  
  // Recalcular calibração sempre que adicionar uma medida
  recalcularCalibracao();
  
  return true;
}

// Função para adicionar uma nova medição (modo medida)
bool addMedicao(int ldrValue, float calculatedConcentration) {
  if (medicaoCount >= MAX_MEDICOES) {
    return false; // Array cheio
  }
  medicoes[medicaoCount].ldrValue = ldrValue;
  medicoes[medicaoCount].calculatedConcentration = calculatedConcentration;
  medicoes[medicaoCount].timestamp = millis() / 1000;
  medicaoCount++;
  return true;
}

// Função para limpar todas as medidas
void clearMeasurements() {
  measurementCount = 0;
  calibracaoAtiva = false;
  calibracao_a = 0;
  calibracao_b = 0;
}

// Função para limpar todas as medições
void clearMedicoes() {
  medicaoCount = 0;
}

// Função para controlar o LED
void setLED(bool status) {
  ledStatus = status;
  if (status) {
    digitalWrite(ledPin, HIGH);
    Serial.println("LED LIGADO - GPIO7");
  } else {
    digitalWrite(ledPin, LOW);
    Serial.println("LED DESLIGADO - GPIO7");
  }
}



// Função para alternar modo
void alternarModo() {
  modoCalibracao = !modoCalibracao;
}

// Função para servir arquivos estáticos
void serveStaticFile(const char* filename, const char* contentType) {
  if (SPIFFS.exists(filename)) {
    File file = SPIFFS.open(filename, "r");
    server.streamFile(file, contentType);
    file.close();
  } else {
    server.send(404, "text/plain", "Arquivo nao encontrado");
  }
}

void setup() {
  Serial.begin(115200);
  

  
  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, LOW);  // Garante que o LED começa desligado
  
  // Teste inicial do LED
  digitalWrite(ledPin, HIGH);
  delay(1000);
  digitalWrite(ledPin, LOW);
  

  
  // Inicializar SPIFFS
  if (!SPIFFS.begin(true)) {
    Serial.println("Erro ao montar SPIFFS");
    return;
  }

  // Configura o ESP32 como Access Point
  WiFi.softAP(ssid, password);
  Serial.print("AP IP address: ");
  Serial.println(WiFi.softAPIP());

  // Configurar CORS para todas as rotas
  server.enableCORS(true);

  // Rota principal - servir a página HTML
  server.on("/", HTTP_GET, [](){
    String html = "<!DOCTYPE html>";
    html += "<html lang=\"pt-BR\">";
    html += "<head>";
    html += "<meta charset=\"UTF-8\">";
    html += "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">";
    html += "<title>Espectroscopio ESP32</title>";
    html += "<script src=\"/chart.js\"></script>";
    html += "<style>";
    html += "* { margin: 0; padding: 0; box-sizing: border-box; }";
    html += "body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 20px; }";
    html += ".container { max-width: 1200px; margin: 0 auto; background: white; border-radius: 20px; box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1); overflow: hidden; }";
    html += ".header { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; padding: 30px; text-align: center; }";
    html += ".header h1 { font-size: 2.5em; margin-bottom: 10px; font-weight: 300; }";
    html += ".header p { font-size: 1.1em; opacity: 0.9; }";
    html += ".content { padding: 40px; display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }";
    html += ".section { background: #f8f9fa; border-radius: 15px; padding: 30px; border: 2px solid #e9ecef; }";
    html += ".section.full-width { grid-column: 1 / -1; }";
    html += ".section h2 { color: #495057; margin-bottom: 20px; font-size: 1.5em; }";
    html += ".button { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; padding: 15px 30px; border-radius: 50px; font-size: 1.1em; cursor: pointer; transition: all 0.3s ease; margin: 10px 5px; box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3); }";
    html += ".button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4); }";
    html += ".button:active { transform: translateY(0); }";
    html += ".button.secondary { background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%); color: #333; }";
    html += ".button.success { background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%); color: #333; }";
    html += ".button.danger { background: linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%); color: white; }";
    html += ".button.warning { background: linear-gradient(135deg, #feca57 0%, #ff9ff3 100%); color: #333; }";
    html += ".button.info { background: linear-gradient(135deg, #48cae4 0%, #023e8a 100%); color: white; }";
    html += ".display-value { background: white; border: 2px solid #e9ecef; border-radius: 10px; padding: 20px; margin: 20px 0; text-align: center; font-size: 1.3em; color: #495057; }";
    html += ".input-group { margin: 20px 0; }";
    html += ".input-group label { display: block; margin-bottom: 8px; color: #495057; font-weight: 500; }";
    html += ".input-group input { width: 100%; padding: 15px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 1.1em; transition: border-color 0.3s ease; }";
    html += ".input-group input:focus { outline: none; border-color: #667eea; }";
    html += ".status { padding: 15px; border-radius: 10px; margin: 20px 0; text-align: center; font-weight: 500; }";
    html += ".status.success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }";
    html += ".status.error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }";
    html += ".status.warning { background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; }";
    html += ".status.info { background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }";
    html += ".hidden { display: none; }";
    html += ".loading { display: inline-block; width: 20px; height: 20px; border: 3px solid #f3f3f3; border-top: 3px solid #667eea; border-radius: 50%; animation: spin 1s linear infinite; margin-right: 10px; }";
    html += "@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }";
    html += ".measurements-list { max-height: 300px; overflow-y: auto; border: 1px solid #e9ecef; border-radius: 10px; padding: 15px; background: white; }";
    html += ".measurement-item { padding: 10px; border-bottom: 1px solid #e9ecef; display: flex; justify-content: space-between; align-items: center; }";
    html += ".measurement-item:last-child { border-bottom: none; }";
    html += ".chart-container { display: flex; justify-content: center; align-items: center; position: relative; height: 400px; margin: 20px 0; }";
    html += "#calibrationChart { background: #fff; width: 100%; height: 400px; margin: 0 auto; display: block; }";
    html += ".calibration-info { background: #e3f2fd; border: 1px solid #2196f3; border-radius: 10px; padding: 15px; margin: 20px 0; }";
    html += ".led-control { background: #e8f5e8; border: 1px solid #4caf50; border-radius: 10px; padding: 15px; margin: 20px 0; text-align: center; }";
    html += ".led-status { font-size: 1.2em; font-weight: bold; margin: 10px 0; }";
    html += ".mode-control { background: #fff3cd; border: 1px solid #ffc107; border-radius: 10px; padding: 15px; margin: 20px 0; text-align: center; }";
    html += ".mode-status { font-size: 1.2em; font-weight: bold; margin: 10px 0; }";
    html += ".upload-section { background: #f0f8ff; border: 2px dashed #4facfe; border-radius: 15px; padding: 20px; margin: 20px 0; text-align: center; }";
    html += ".upload-section:hover { border-color: #667eea; background: #e6f3ff; }";
    html += ".file-input { display: none; }";
    html += ".upload-label { cursor: pointer; display: inline-block; padding: 15px 30px; background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; border-radius: 50px; font-size: 1.1em; transition: all 0.3s ease; }";
    html += ".upload-label:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(79, 172, 254, 0.4); }";
    html += "@media (max-width: 768px) { .container { margin: 10px; border-radius: 15px; } .content { padding: 20px; grid-template-columns: 1fr; gap: 20px; } .header { padding: 20px; } .header h1 { font-size: 2em; } }";
    html += "</style>";
    html += "</head>";
    html += "<body>";
    html += "<div class=\"container\">";
    html += "<div class=\"header\">";
    html += "<h1>Espectroscopio ESP32</h1>";
    html += "<p>Sistema de medicao e analise espectroscopica com calibracao automatica</p>";
    html += "</div>";
    html += "<div class=\"content\">";
    html += "<div class=\"section\">";
    html += "<h2>Controle do LED</h2>";
    html += "<div class=\"led-control\">";
    html += "<div class=\"led-status\" id=\"led-status\">LED: Desligado</div>";
    html += "<button class=\"button success\" onclick=\"ligarLED()\">Ligar LED</button>";
    html += "<button class=\"button danger\" onclick=\"desligarLED()\">Desligar LED</button>";
    html += "</div>";
    html += "<h2>Modo de Operacao</h2>";
    html += "<div class=\"mode-control\">";
    html += "<div class=\"mode-status\" id=\"mode-status\">Modo: Calibracao</div>";
    html += "<button class=\"button info\" onclick=\"alternarModo()\">Alternar Modo</button>";
    html += "</div>";
    html += "<h2>Realizar Medicao</h2>";
    html += "<button class=\"button\" onclick=\"realizarMedicao()\">";
    html += "<span id=\"loading-measure\" class=\"loading hidden\"></span>";
    html += "Medir LDR (Media de 3 leituras)";
    html += "</button>";
    html += "<div id=\"valor-ldr\" class=\"display-value hidden\">";
    html += "<strong>Valor do LDR:</strong> <span id=\"ldr-value\">-</span>";
    html += "</div>";
    html += "<div id=\"concentracao-calculada\" class=\"display-value hidden\">";
    html += "<strong>Concentracao Calculada:</strong> <span id=\"calc-concentration\">-</span>";
    html += "</div>";
    html += "<div id=\"calibracao-section\" class=\"hidden\">";
    html += "<div class=\"input-group\">";
    html += "<label for=\"concentracao\">Concentracao real da amostra (mg/L):</label>";
    html += "<input type=\"number\" id=\"concentracao\" step=\"0.000001\" placeholder=\"Digite a concentracao com 6 casas decimais\">";
    html += "</div>";
    html += "<button class=\"button success\" onclick=\"salvarCalibracao()\">";
    html += "<span id=\"loading-register\" class=\"loading hidden\"></span>";
    html += "Salvar Ponto de Calibracao";
    html += "</button>";
    html += "<button class=\"button secondary\" onclick=\"cancelarMedida()\">Cancelar</button>";
    html += "</div>";
    html += "<div id=\"status-message\" class=\"status hidden\"></div>";
    html += "</div>";
    html += "<div class=\"section\">";
    html += "<h2>Dados Coletados</h2>";
    html += "<button class=\"button\" onclick=\"carregarDados()\">Atualizar Dados</button>";
    html += "<button class=\"button secondary\" onclick=\"mostrarExportarCSV()\">Exportar Calibração</button>";
    html += "<button class=\"button secondary\" onclick=\"exportarMedicoes()\">Exportar Medidas</button>";
    html += "<button class=\"button secondary\" onclick=\"salvarGrafico()\">Salvar Grafico</button>";
    html += "<button class=\"button warning\" onclick=\"limparDados()\">Limpar Dados</button>";
    html += "<div id=\"exportar-section\" class=\"hidden\">";
    html += "<div class=\"input-group\">";
    html += "<label for=\"nome-experimento\">Nome do Experimento/Amostra:</label>";
    html += "<input type=\"text\" id=\"nome-experimento\" placeholder=\"Ex: Calibracao_Acido_Ascorbico_2024\" maxlength=\"50\">";
    html += "</div>";
    html += "<button class=\"button success\" onclick=\"exportarCSV()\">Confirmar Exportacao</button>";
    html += "<button class=\"button secondary\" onclick=\"cancelarExportar()\">Cancelar</button>";
    html += "</div>";
    html += "<div class=\"upload-section\">";
    html += "<h3 style=\"margin-bottom: 15px; color: #495057;\">Importar Curva de Calibração</h3>";
    html += "<p style=\"margin-bottom: 20px; color: #666; font-size: 0.9em;\">Selecione um arquivo CSV exportado anteriormente para carregar os dados de calibração</p>";
    html += "<input type=\"file\" id=\"fileInput\" class=\"file-input\" accept=\".csv\" onchange=\"handleFileUpload(event)\">";
    html += "<label for=\"fileInput\" class=\"upload-label\">Escolher Arquivo CSV</label>";
    html += "<div id=\"upload-status\" class=\"status hidden\"></div>";
    html += "</div>";
    html += "<div id=\"calibration-status\" class=\"calibration-info hidden\">";
    html += "<strong>Status da Calibracao:</strong> <span id=\"calibration-text\">-</span>";
    html += "</div>";
    html += "<div id=\"measurements-container\" class=\"measurements-list\">";
    html += "<p>Nenhuma medida cadastrada ainda.</p>";
    html += "</div>";
    html += "</div>";
    html += "<div class=\"section full-width\">";
    html += "<h2>Grafico de Calibracao</h2>";
    html += "<div class=\"chart-container\">";
    html += "<canvas id=\"calibrationChart\"></canvas>";
    html += "</div>";
    html += "</div>";
    html += "</div>";
    html += "<div style=\"width:100%; text-align:center; margin-top:40px; padding:20px; border-top: 1px solid #e9ecef;\">";
    html += "<span style=\"font-size:0.85em; color:#495057; opacity:0.7; letter-spacing:0.5px;\">Desenvolvido por Kaique de Sotti Silva na Universidade Federal da Integração Latino-Americana</span>";
    html += "</div>";
    html += "</div>";
    html += "<script>";
    html += "let currentLDRValue = null;";
    html += "let measurements = [];";
    html += "let chart = null;";
    html += "let chartEquation = { a: 0, b: 0, r2: 0 };";
    html += "let ledStatus = false;";
    html += "let modoCalibracao = true;";
    html += "function linearRegression(x, y) {";
    html += "const n = x.length;";
    html += "const sumX = x.reduce((a, b) => a + b, 0);";
    html += "const sumY = y.reduce((a, b) => a + b, 0);";
    html += "const sumXY = x.reduce((acc, xi, i) => acc + xi * y[i], 0);";
    html += "const sumX2 = x.reduce((acc, xi) => acc + xi * xi, 0);";
    html += "const a = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);";
    html += "const b = (sumY - a * sumX) / n;";
    html += "const meanY = sumY / n;";
    html += "const ssTot = y.reduce((acc, yi) => acc + (yi - meanY) ** 2, 0);";
    html += "const ssRes = y.reduce((acc, yi, i) => acc + (yi - (a * x[i] + b)) ** 2, 0);";
    html += "const r2 = 1 - ssRes / ssTot;";
    html += "return { a, b, r2 };";
    html += "}";
    html += "function initChart() {";
    html += "const ctx = document.getElementById('calibrationChart').getContext('2d');";
    html += "chart = new Chart(ctx, {";
    html += "type: 'scatter',";
    html += "data: { datasets: [";
    html += "{ label: 'Pontos de Calibração', data: [], backgroundColor: 'blue' },";
    html += "{ label: '', data: [], type: 'line', borderColor: 'red', borderWidth: 2, fill: false, pointRadius: 0 }";
    html += "] },";
    html += "options: { responsive: true, plugins: { legend: { position: 'top' } }, scales: { x: { title: { display: true, text: 'Valor do LDR' } }, y: { title: { display: true, text: 'Concentração (mg/L)' } } }, plugins: { equationLabel: {} } }, plugins: [equationLabelPlugin]";
    html += "});";
    html += "}";
    // Plugin para desenhar a equação e R² no canto superior direito
    html += "const equationLabelPlugin = {";
    html += "  id: 'equationLabel',";
    html += "  afterDraw(chart, args, options) {";
    html += "    if (!chartEquation || chart.data.datasets[1].data.length === 0) return;";
    html += "    const { a, b, r2 } = chartEquation;";
    html += "    const ctx = chart.ctx;";
    html += "    ctx.save();";
    html += "    ctx.font = 'bold 15px Segoe UI, Arial';";
    html += "    ctx.fillStyle = '#333';";
    html += "    const text = `y = ${a.toFixed(4)}x + ${b.toFixed(4)}   R² = ${r2.toFixed(4)}`;";
    html += "    ctx.textAlign = 'right';";
    html += "    ctx.fillText(text, chart.chartArea.right - 10, chart.chartArea.top + 25);";
    html += "    ctx.restore();";
    html += "  }";
    html += "};";
    html += "function updateChart() {";
    html += "console.log('Chamando updateChart, measurements:', measurements);";
    html += "if (!chart || measurements.length === 0) return;";
    html += "const x = measurements.map(m => m.ldrValue);";
    html += "const y = measurements.map(m => m.concentration);";
    html += "chart.data.datasets[0].data = measurements.map(m => ({ x: m.ldrValue, y: m.concentration }));";
    html += "if (measurements.length >= 2) {";
    html += "const { a, b, r2 } = linearRegression(x, y);";
    html += "chartEquation = { a, b, r2 };";
    html += "const minX = Math.min(...x);";
    html += "const maxX = Math.max(...x);";
    html += "chart.data.datasets[1].data = [ { x: minX, y: a * minX + b }, { x: maxX, y: a * maxX + b } ];";
    html += "chart.data.datasets[1].label = `Ajuste Linear (y = ${a.toFixed(4)}x + ${b.toFixed(4)}, R² = ${r2.toFixed(4)})`;";
    html += "} else { chart.data.datasets[1].data = []; chart.data.datasets[1].label = ''; chartEquation = { a: 0, b: 0, r2: 0 }; }";
    html += "chart.update();";
    html += "}";
    html += "async function ligarLED() {";
    html += "try {";
    html += "const response = await fetch('/led/ligar', { method: 'POST' });";
    html += "if (response.ok) {";
    html += "ledStatus = true;";
    html += "document.getElementById('led-status').textContent = 'LED: Ligado';";
    html += "document.getElementById('led-status').style.color = '#4caf50';";
    html += "showStatus('LED ligado com sucesso!', 'success');";
    html += "} else {";
    html += "showStatus('Erro ao ligar LED.', 'error');";
    html += "}";
    html += "} catch (error) {";
    html += "showStatus('Erro ao ligar LED: ' + error.message, 'error');";
    html += "}";
    html += "}";
    html += "async function desligarLED() {";
    html += "try {";
    html += "const response = await fetch('/led/desligar', { method: 'POST' });";
    html += "if (response.ok) {";
    html += "ledStatus = false;";
    html += "document.getElementById('led-status').textContent = 'LED: Desligado';";
    html += "document.getElementById('led-status').style.color = '#f44336';";
    html += "showStatus('LED desligado com sucesso!', 'success');";
    html += "} else {";
    html += "showStatus('Erro ao desligar LED.', 'error');";
    html += "}";
    html += "} catch (error) {";
    html += "showStatus('Erro ao desligar LED: ' + error.message, 'error');";
    html += "}";
    html += "}";

    html += "async function alternarModo() {";
    html += "try {";
    html += "const response = await fetch('/modo/alternar', { method: 'POST' });";
    html += "if (response.ok) {";
    html += "modoCalibracao = !modoCalibracao;";
    html += "const modeStatus = document.getElementById('mode-status');";
    html += "if (modoCalibracao) {";
    html += "modeStatus.textContent = 'Modo: Calibracao';";
    html += "modeStatus.style.color = '#ffc107';";
    html += "showStatus('Modo alterado para Calibracao', 'info');";
    html += "} else {";
    html += "modeStatus.textContent = 'Modo: Medida';";
    html += "modeStatus.style.color = '#4caf50';";
    html += "showStatus('Modo alterado para Medida', 'info');";
    html += "}";
    html += "} else {";
    html += "showStatus('Erro ao alternar modo.', 'error');";
    html += "}";
    html += "} catch (error) {";
    html += "showStatus('Erro ao alternar modo: ' + error.message, 'error');";
    html += "}";
    html += "}";
    html += "async function realizarMedicao() {";
    html += "if (!ledStatus) {";
    html += "showStatus('Ligue o LED primeiro antes de realizar a medicao!', 'warning');";
    html += "return;";
    html += "}";
    html += "const loadingElement = document.getElementById('loading-measure');";
    html += "const button = event.target;";
    html += "loadingElement.classList.remove('hidden');";
    html += "button.disabled = true;";
    html += "try {";
    html += "const response = await fetch('/medir');";
    html += "const data = await response.json();";
    html += "currentLDRValue = data.ldrValue;";
    html += "document.getElementById('ldr-value').textContent = currentLDRValue;";
    html += "document.getElementById('valor-ldr').classList.remove('hidden');";
    html += "if (modoCalibracao) {";
    html += "document.getElementById('calibracao-section').classList.remove('hidden');";
    html += "document.getElementById('concentracao-calculada').classList.add('hidden');";
    html += "showStatus('Medicao realizada! Digite a concentracao real para calibracao.', 'info');";
    html += "} else {";
    html += "if (data.calculatedConcentration !== undefined && data.calculatedConcentration >= 0) {";
    html += "document.getElementById('calc-concentration').textContent = data.calculatedConcentration.toFixed(6) + ' mg/L';";
    html += "document.getElementById('concentracao-calculada').classList.remove('hidden');";
    html += "} else {";
    html += "document.getElementById('calc-concentration').textContent = 'Calibracao necessaria';";
    html += "document.getElementById('concentracao-calculada').classList.remove('hidden');";
    html += "}";
    html += "document.getElementById('calibracao-section').classList.add('hidden');";
    html += "showStatus('Medicao realizada! Concentracao calculada.', 'success');";
    html += "}";
    html += "} catch (error) {";
    html += "showStatus('Erro ao realizar medicao: ' + error.message, 'error');";
    html += "} finally {";
    html += "loadingElement.classList.add('hidden');";
    html += "button.disabled = false;";
    html += "}";
    html += "}";
    html += "async function salvarCalibracao() {";
    html += "const concentracao = document.getElementById('concentracao').value;";
    html += "if (!concentracao || !currentLDRValue) {";
    html += "showStatus('Por favor, insira a concentracao e realize uma medicao primeiro.', 'error');";
    html += "return;";
    html += "}";
    html += "const loadingElement = document.getElementById('loading-register');";
    html += "const button = event.target;";
    html += "loadingElement.classList.remove('hidden');";
    html += "button.disabled = true;";
    html += "try {";
    html += "const formData = new FormData();";
    html += "formData.append('ldrValue', currentLDRValue);";
    html += "formData.append('concentration', concentracao);";
    html += "const response = await fetch('/cadastrar', {";
    html += "method: 'POST',";
    html += "body: formData";
    html += "});";
    html += "if (response.ok) {";
    html += "showStatus('Ponto de calibracao salvo com sucesso!', 'success');";
    html += "document.getElementById('concentracao').value = '';";
    html += "document.getElementById('calibracao-section').classList.add('hidden');";
    html += "carregarDados();";
    html += "updateChart();";
    html += "} else {";
    html += "showStatus('Erro ao salvar ponto de calibracao.', 'error');";
    html += "}";
    html += "} catch (error) {";
    html += "showStatus('Erro ao salvar ponto de calibracao: ' + error.message, 'error');";
    html += "} finally {";
    html += "loadingElement.classList.add('hidden');";
    html += "button.disabled = false;";
    html += "}";
    html += "}";
    html += "function cancelarMedida() {";
    html += "currentLDRValue = null;";
    html += "document.getElementById('valor-ldr').classList.add('hidden');";
    html += "document.getElementById('concentracao-calculada').classList.add('hidden');";
    html += "document.getElementById('calibracao-section').classList.add('hidden');";
    html += "document.getElementById('concentracao').value = '';";
    html += "hideStatus();";
    html += "}";
    html += "async function carregarDados() {";
    html += "try {";
    html += "const response = await fetch('/dados');";
    html += "const data = await response.json();";
    html += "measurements = data.measurements || [];";
    html += "modoCalibracao = data.modoCalibracao || true;";
    html += "const container = document.getElementById('measurements-container');";
    html += "const modeStatus = document.getElementById('mode-status');";
    html += "if (modoCalibracao) { modeStatus.textContent = 'Modo: Calibracao'; modeStatus.style.color = '#ffc107'; } else { modeStatus.textContent = 'Modo: Medida'; modeStatus.style.color = '#4caf50'; }";
    html += "if (data.calibracaoAtiva) { calibracao_a = data.calibracao_a || 0; calibracao_b = data.calibracao_b || 0; calibracaoAtiva = true; }";
    html += "if (measurements.length === 0) { container.innerHTML = '<p>Nenhuma medida cadastrada ainda.</p>'; document.getElementById('calibration-status').classList.add('hidden'); } else { let htmlContent = ''; for (let i = 0; i < measurements.length; i++) { htmlContent += '<div class=\"measurement-item\">'; htmlContent += '<span><strong>Ponto ' + (i + 1) + ':</strong> LDR: ' + measurements[i].ldrValue + '</span>'; htmlContent += '<span>Concentracao: ' + measurements[i].concentration.toFixed(6) + ' mg/L</span>'; htmlContent += '</div>'; } container.innerHTML = htmlContent; const calibrationStatus = document.getElementById('calibration-status'); const calibrationText = document.getElementById('calibration-text'); if (data.calibracaoAtiva) { calibrationText.textContent = 'Calibracao ativa com ' + measurements.length + ' pontos (a=' + data.calibracao_a.toFixed(6) + ', b=' + data.calibracao_b.toFixed(6) + ')'; calibrationStatus.classList.remove('hidden'); } else { calibrationText.textContent = 'Necessario pelo menos 2 pontos para calibracao (atual: ' + measurements.length + ')'; calibrationStatus.classList.remove('hidden'); } } updateChart(); } catch (error) { showStatus('Erro ao carregar dados: ' + error.message, 'error'); } }";
    html += "async function limparDados() {";
    html += "if (confirm('Tem certeza que deseja limpar todos os dados? Esta acao nao pode ser desfeita.')) {";
    html += "try {";
    html += "const response = await fetch('/limpar', {";
    html += "method: 'POST'";
    html += "});";
    html += "if (response.ok) {";
    html += "showStatus('Dados limpos com sucesso!', 'success');";
    html += "measurements = [];";
    html += "chartEquation = { a: 0, b: 0, r2: 0 };";
    html += "if (chart) {";
    html += "chart.data.datasets[0].data = [];";
    html += "chart.data.datasets[1].data = [];";
    html += "chart.data.datasets[1].label = '';";
    html += "chart.update();";
    html += "}";
    html += "document.getElementById('measurements-container').innerHTML = '<p>Nenhuma medida cadastrada ainda.</p>';";
    html += "document.getElementById('calibration-status').classList.add('hidden');";
    html += "} else {";
    html += "showStatus('Erro ao limpar dados.', 'error');";
    html += "}";
    html += "} catch (error) {";
    html += "showStatus('Erro ao limpar dados: ' + error.message, 'error');";
    html += "}";
    html += "}";
    html += "}";
    html += "function exportarCSV() {";
    html += "if (measurements.length === 0) {";
    html += "showStatus('Nenhuma medida para exportar.', 'error');";
    html += "return;";
    html += "}";
    html += "const nomeExperimento = document.getElementById('nome-experimento').value.trim();";
    html += "if (!nomeExperimento) {";
    html += "showStatus('Por favor, insira um nome para o experimento.', 'error');";
    html += "return;";
    html += "}";
    html += "const nomeArquivo = nomeExperimento.replace(/[^a-zA-Z0-9_-]/g, '_') + '_calibracao.csv';";
    html += "let csvContent = 'data:text/csv;charset=utf-8,';";
    html += "csvContent += 'Ponto,Valor_LDR,Concentracao_mg_L,Timestamp\\n';";
    html += "for (let i = 0; i < measurements.length; i++) {";
    html += "const date = new Date(measurements[i].timestamp * 1000);";
    html += "csvContent += (i + 1) + ',' + measurements[i].ldrValue + ',' + measurements[i].concentration.toFixed(6) + ',' + date.toLocaleString() + '\\n';";
    html += "}";
    html += "const encodedUri = encodeURI(csvContent);";
    html += "const link = document.createElement('a');";
    html += "link.setAttribute('href', encodedUri);";
    html += "link.setAttribute('download', nomeArquivo);";
    html += "document.body.appendChild(link);";
    html += "link.click();";
    html += "document.body.removeChild(link);";
    html += "showStatus('Arquivo ' + nomeArquivo + ' exportado com sucesso!', 'success');";
    html += "document.getElementById('exportar-section').classList.add('hidden');";
    html += "document.getElementById('nome-experimento').value = '';";
    html += "}";
    html += "function mostrarExportarCSV() {";
    html += "if (measurements.length === 0) {";
    html += "showStatus('Nenhuma medida para exportar.', 'error');";
    html += "return;";
    html += "}";
    html += "document.getElementById('exportar-section').classList.remove('hidden');";
    html += "document.getElementById('nome-experimento').focus();";
    html += "}";
    html += "function cancelarExportar() {";
    html += "document.getElementById('exportar-section').classList.add('hidden');";
    html += "document.getElementById('nome-experimento').value = '';";
    html += "}";
    html += "function salvarGrafico() {";
    html += "if (!chart || measurements.length === 0) {";
    html += "showStatus('Nenhum grafico para salvar.', 'error');";
    html += "return;";
    html += "}";
    html += "const link = document.createElement('a');";
    html += "link.download = 'grafico_calibracao.png';";
    html += "link.href = chart.toBase64Image();";
    html += "link.click();";
    html += "showStatus('Grafico salvo com sucesso!', 'success');";
    html += "}";
    html += "function handleFileUpload(event) {";
    html += "const file = event.target.files[0];";
    html += "if (!file) return;";
    html += "if (!file.name.toLowerCase().endsWith('.csv')) {";
    html += "showStatus('Por favor, selecione um arquivo CSV válido.', 'error');";
    html += "return;";
    html += "}";
    html += "const reader = new FileReader();";
    html += "reader.onload = function(e) {";
    html += "try {";
    html += "const csvContent = e.target.result;";
    html += "const lines = csvContent.split('\\n');";
    html += "if (lines.length < 2) {";
    html += "showStatus('Arquivo CSV inválido ou vazio.', 'error');";
    html += "return;";
    html += "}";
    html += "const newMeasurements = [];";
    html += "for (let i = 1; i < lines.length; i++) {";
    html += "const line = lines[i].trim();";
    html += "if (line === '') continue;";
    html += "const parts = line.split(',');";
    html += "if (parts.length >= 3) {";
    html += "const ldrValue = parseInt(parts[1]);";
    html += "const concentration = parseFloat(parts[2]);";
    html += "if (!isNaN(ldrValue) && !isNaN(concentration)) {";
    html += "newMeasurements.push({ ldrValue, concentration, timestamp: Math.floor(Date.now() / 1000) });";
    html += "}";
    html += "}";
    html += "}";
    html += "if (newMeasurements.length === 0) {";
    html += "showStatus('Nenhum dado válido encontrado no arquivo CSV.', 'error');";
    html += "return;";
    html += "}";
    html += "uploadMeasurements(newMeasurements);";
    html += "} catch (error) {";
    html += "showStatus('Erro ao processar arquivo CSV: ' + error.message, 'error');";
    html += "}";
    html += "};";
    html += "reader.readAsText(file);";
    html += "}";
    html += "async function uploadMeasurements(newMeasurements) {";
    html += "try {";
    html += "const response = await fetch('/upload', {";
    html += "method: 'POST',";
    html += "headers: { 'Content-Type': 'application/json' },";
    html += "body: JSON.stringify({ measurements: newMeasurements })";
    html += "});";
    html += "if (response.ok) {";
    html += "showStatus('Curva de calibração importada com sucesso! ' + newMeasurements.length + ' pontos carregados.', 'success');";
    html += "carregarDados();";
    html += "updateChart();";
    html += "} else {";
    html += "showStatus('Erro ao importar dados.', 'error');";
    html += "}";
    html += "} catch (error) {";
    html += "showStatus('Erro ao importar dados: ' + error.message, 'error');";
    html += "}";
    html += "}";
    html += "function showStatus(message, type) {";
    html += "const statusElement = document.getElementById('status-message');";
    html += "statusElement.textContent = message;";
    html += "statusElement.className = 'status ' + type;";
    html += "statusElement.classList.remove('hidden');";
    html += "setTimeout(function() {";
    html += "hideStatus();";
    html += "}, 5000);";
    html += "}";
    html += "function hideStatus() {";
    html += "document.getElementById('status-message').classList.add('hidden');";
    html += "}";
    html += "function exportarMedicoes() {";
    html += "window.open('/exportar-medidas', '_blank');";
    html += "showStatus('Arquivo de medidas exportado!', 'success');";
    html += "}";
    html += "window.onload = function() { initChart(); carregarDados(); };";
    html += "</script>";
    html += "</body>";
    html += "</html>";
    
    server.send(200, "text/html", html);
  });

  // Rota para ligar LED
  server.on("/led/ligar", HTTP_POST, [](){
    setLED(true);
    server.send(200, "text/plain", "LED ligado");
  });

  // Rota para desligar LED
  server.on("/led/desligar", HTTP_POST, [](){
    setLED(false);
    server.send(200, "text/plain", "LED desligado");
  });

  // Rota para alternar modo
  server.on("/modo/alternar", HTTP_POST, [](){
    alternarModo();
    server.send(200, "text/plain", "Modo alternado");
  });



  // Rota para medir LDR (com media de 3 leituras)
  server.on("/medir", HTTP_GET, [](){
    int ldrValue = readLDRAverage();
    float calculatedConcentration = calculateConcentration(ldrValue);

    DynamicJsonDocument doc(1024);
    doc["ldrValue"] = ldrValue;
    doc["calculatedConcentration"] = calculatedConcentration;

    // Se estiver no modo de medição, salva a medição
    if (!modoCalibracao) {
      addMedicao(ldrValue, calculatedConcentration);
    }

    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
  });

  // Rota para cadastrar medida
  server.on("/cadastrar", HTTP_POST, [](){
    if (server.hasArg("ldrValue") && server.hasArg("concentration")) {
      int ldrValue = server.arg("ldrValue").toInt();
      float concentration = server.arg("concentration").toFloat();

      if (addMeasurement(ldrValue, concentration)) {
        server.send(200, "text/plain", "Medida cadastrada com sucesso!");
      } else {
        server.send(500, "text/plain", "Erro: limite de medidas atingido.");
      }
    } else {
      server.send(400, "text/plain", "Parametros invalidos.");
    }
  });

  // Rota para obter todas as medidas cadastradas
  server.on("/dados", HTTP_GET, [](){
    DynamicJsonDocument doc(4096);
    JsonArray array = doc.to<JsonArray>();

    for (int i = 0; i < measurementCount; i++) {
      JsonObject obj = array.createNestedObject();
      obj["ldrValue"] = measurements[i].ldrValue;
      obj["concentration"] = measurements[i].concentration;
      obj["timestamp"] = measurements[i].timestamp;
    }

    String response;
    serializeJson(doc, response);
    
    // Criar resposta completa com dados adicionais
    String fullResponse = "{\"measurements\":" + response + ",\"modoCalibracao\":" + String(modoCalibracao ? "true" : "false") + ",\"calibracaoAtiva\":" + String(calibracaoAtiva ? "true" : "false") + ",\"calibracao_a\":" + String(calibracao_a, 6) + ",\"calibracao_b\":" + String(calibracao_b, 6) + "}";
    
    server.send(200, "application/json", fullResponse);
  });

  // Rota para exportar dados de calibração em CSV
  server.on("/exportar-csv", HTTP_GET, [](){
    String csvContent = "Ponto,Valor_LDR,Concentracao_mg_L,Timestamp\n";
    for (int i = 0; i < measurementCount; i++) {
      csvContent += String(i + 1) + "," + 
                   String(measurements[i].ldrValue) + "," + 
                   String(measurements[i].concentration, 6) + "," + 
                   String(measurements[i].timestamp) + "\n";
    }
    server.send(200, "text/csv", csvContent);
  });

  // Rota para exportar dados de medições em CSV
  server.on("/exportar-medidas", HTTP_GET, [](){
    String csvContent = "Ponto,Valor_LDR,Concentracao_Calculada_mg_L,Timestamp\n";
    for (int i = 0; i < medicaoCount; i++) {
      csvContent += String(i + 1) + "," + 
                   String(medicoes[i].ldrValue) + "," + 
                   String(medicoes[i].calculatedConcentration, 6) + "," + 
                   String(medicoes[i].timestamp) + "\n";
    }
    server.send(200, "text/csv", csvContent);
  });

  // Rota para limpar todas as medições
  server.on("/limpar-medicoes", HTTP_POST, [](){
    clearMedicoes();
    server.send(200, "text/plain", "Todas as medições foram removidas.");
  });

  // Rota para limpar todas as medidas E medições
  server.on("/limpar", HTTP_POST, [](){
    clearMeasurements();
    clearMedicoes();
    server.send(200, "text/plain", "Todas as medidas e medições foram removidas.");
  });

  // Rota para upload de dados de calibração
  server.on("/upload", HTTP_POST, [](){
    if (server.hasArg("plain")) {
      String jsonData = server.arg("plain");
      DynamicJsonDocument doc(8192);
      DeserializationError error = deserializeJson(doc, jsonData);
      
      if (error) {
        server.send(400, "text/plain", "Erro ao processar JSON");
        return;
      }
      
      JsonArray measurementsArray = doc["measurements"];
      if (!measurementsArray) {
        server.send(400, "text/plain", "Dados invalidos");
        return;
      }
      
      // Limpar dados existentes
      clearMeasurements();
      
      // Adicionar novos dados
      int addedCount = 0;
      for (JsonObject measurement : measurementsArray) {
        if (measurementCount >= MAX_MEASUREMENTS) break;
        
        int ldrValue = measurement["ldrValue"];
        float concentration = measurement["concentration"];
        
        if (addMeasurement(ldrValue, concentration)) {
          addedCount++;
        }
      }
      
      server.send(200, "text/plain", "Upload realizado com sucesso. " + String(addedCount) + " pontos adicionados.");
    } else {
      server.send(400, "text/plain", "Dados nao recebidos");
    }
  });

  // Rota para servir o Chart.js local do SPIFFS
  server.on("/chart.js", HTTP_GET, []() {
    serveStaticFile("/chart.js", "application/javascript");
  });

  // Inicia o servidor
  server.begin();
  Serial.println("Servidor web iniciado!");
  Serial.println("Conecte-se a rede: " + String(ssid));
  Serial.println("Acesse: http://" + WiFi.softAPIP().toString());
}

void loop() {
  // O loop principal pode ficar vazio, pois o servidor web é assíncrono
  server.handleClient();
  delay(10);
}