# Adaptação para ESP32-C3 Mini

## Mudanças Realizadas

### Pinos Alterados

| Componente | ESP32 Original | ESP32-C3 Mini | Observações |
|------------|----------------|---------------|-------------|
| LED        | GPIO25         | GPIO8         | Saída digital |
| LDR        | GPIO34         | GPIO4         | Entrada analógica |

### Código Modificado

No arquivo `espectroscopio_completo.ino`, as seguintes linhas foram alteradas:

```cpp
// Pinos - Adaptados para ESP32-C3 Mini
const int ledPin = 8;        // LED no GPIO8 (ESP32-C3 Mini)
const int ldrPin = 4;        // LDR no GPIO4 (ESP32-C3 Mini - entrada analógica)
```

## Características do ESP32-C3 Mini

### Pinagem Relevante
- **GPIO8**: Saída digital (usado para LED)
- **GPIO4**: Entrada analógica (usado para LDR)
- **GPIO0**: Boot mode
- **GPIO1**: UART0 TX
- **GPIO2**: UART0 RX
- **GPIO3**: UART0 CTS
- **GPIO5**: SPI CS0
- **GPIO6**: SPI CLK
- **GPIO7**: SPI MOSI
- **GPIO9**: SPI MISO

### Especificações Técnicas
- **Processador**: RISC-V de 32 bits
- **Frequência**: Até 160 MHz
- **RAM**: 400 KB SRAM
- **Flash**: 4 MB
- **Wi-Fi**: 802.11 b/g/n
- **Bluetooth**: BLE 5.0
- **Tensão**: 3.3V
- **Corrente**: Até 500mA

### Vantagens do ESP32-C3 Mini
1. **Menor consumo de energia** comparado ao ESP32 tradicional
2. **Processador RISC-V** mais eficiente
3. **Menor tamanho físico**
4. **Melhor relação custo-benefício**
5. **Compatibilidade com bibliotecas ESP32**

### Considerações Importantes
- O ESP32-C3 Mini tem menos GPIOs disponíveis que o ESP32 tradicional
- Alguns pinos têm funções específicas (boot, UART, SPI)
- A resolução ADC é de 12 bits (0-4095)
- Tensão de referência ADC: 3.3V

## Conexões Físicas

### LED
- **Anodo (+)**: Conectar ao GPIO8 através de um resistor de 220Ω
- **Catodo (-)**: Conectar ao GND

### LDR (Sensor de Luz)
- **Terminal 1**: Conectar ao 3.3V
- **Terminal 2**: Conectar ao GPIO4 e a um resistor de 10kΩ para GND (divisor de tensão)

## Funcionalidades Mantidas
- ✅ Servidor web WiFi
- ✅ Interface gráfica
- ✅ Calibração automática
- ✅ Exportação de dados CSV
- ✅ Gráficos em tempo real
- ✅ Modo calibração e medição
- ✅ Armazenamento em SPIFFS

## Compilação e Upload
1. Selecione a placa "ESP32C3 Dev Module" no Arduino IDE
2. Configure a porta COM correta
3. Compile e faça upload do código
4. Acesse o IP do ESP32-C3 Mini via navegador

## Troubleshooting
- Se o LED não acender, verifique se está conectado ao GPIO8
- Se o LDR não funcionar, verifique a conexão do divisor de tensão no GPIO4
- Para problemas de WiFi, verifique se o SSID "ESP32_Espectroscopio" aparece 